<<<<<<< HEAD
from django.apps import AppConfig


class ProfessionalsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'professionals'
=======
from django.apps import AppConfig


class ProfessionalsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'professionals'
>>>>>>> 100bba5 (Inititial commit)
